*------------------------------------------------------------
* 0) Import data and check variables
*------------------------------------------------------------
clear

import delimited "C:\Users\q33044\Desktop\Research\Revision_Ecuador_WD\Data\Data_estimation_rev.csv" // Replace here your directory
gen log_ila = log(ila+1)
gen log_ipcf = log(ipcf+1)
gen sector = .
replace sector = 1 if inlist(ecsec,2,6)    // Primary
replace sector = 2 if inlist(ecsec,4,5)    // Secondary
replace sector = 3 if inlist(ecsec,1,3)    // Tertiary
label define sector 1 "Primary" 2 "Secondary" 3 "Tertiary"

*------------------------------------------------------------
* 1) Excess
*------------------------------------------------------------
eststo clear
gen index1 = binary_excess_1

* ---- Labor income (ila) (Table 3)

qregfe log_ila c.index1 i.estado_civil i.hombre edad temp_max temp_min if binary_deficit_1==0, mmqreg q(10,25,50,75,90) abs(region_est3 year) cluster(region_est3)

qregfe log_ila i.sector#c.index1 i.estado_civil i.hombre edad temp_max temp_min if binary_deficit_1==0, mmqreg q(10,25,50,75,90) abs(region_est3 year) cluster(region_est3)

* --- Plot (Figure 16)

mmqreg log_ila i.sector#c.index1 i.estado_civil i.hombre edad temp_max temp_min if binary_deficit_1==0, q(50) abs(region_est3 year) cluster(region_est3)
qregplot, estore(ila_excess)
qregplot 1.sector#c.index1, from(ila_excess) name(ila_excess_primary, replace) title("Primary")
qregplot 2.sector#c.index1, from(ila_excess) name(ila_excess_secondary, replace) title("Secondary")
qregplot 3.sector#c.index1, from(ila_excess) name(ila_excess_tertiary, replace) title("Tertiary")
graph combine ila_excess_primary ila_excess_secondary ila_excess_tertiary, col(3)
graph export "C:\Users\q33044\Desktop\Research\Revision_Ecuador_WD\Figures\qregplot_ila_excess.pdf", replace

* --- Household income (ipcf) (Table 3)

qregfe log_ipcf c.index1 i.estado_civil i.hombre edad temp_max temp_min if binary_deficit_1==0, mmqreg q(10,25,50,75,90) abs(region_est3 year) cluster(region_est3)

qregfe log_ipcf i.sector#c.index1 i.estado_civil i.hombre edad temp_max temp_min if binary_deficit_1==0, mmqreg q(10,25,50,75,90) abs(region_est3 year) cluster(region_est3)

* --- Plot (Figure 16)

mmqreg log_ipcf i.sector#c.index1 i.estado_civil i.hombre edad temp_max temp_min if binary_deficit_1==0, q(50) abs(region_est3 year) cluster(region_est3)
qregplot, estore(ipcf_excess)
qregplot 1.sector#c.index1, from(ipcf_excess) name(ipcf_excess_primary, replace) title("Primary")
qregplot 2.sector#c.index1, from(ipcf_excess) name(ipcf_excess_secondary, replace) title("Secondary")
qregplot 3.sector#c.index1, from(ipcf_excess) name(ipcf_excess_tertiary, replace) title("Tertiary")
graph combine ipcf_excess_primary ipcf_excess_secondary ipcf_excess_tertiary, col(3)
graph export "C:\Users\q33044\Desktop\Research\Revision_Ecuador_WD\Figures\qregplot_ipcf_excess.pdf", replace

*------------------------------------------------------------
* 2) Deficit
*------------------------------------------------------------
eststo clear
gen index2 = binary_deficit_1

* ---- Labor income (ila) (Table 4)

qregfe log_ila c.index2 i.estado_civil i.hombre edad temp_max temp_min if binary_excess_1==0, mmqreg q(10,25,50,75,90) abs(region_est3 year) cluster(region_est3)

qregfe log_ila i.sector#c.index2 i.estado_civil i.hombre edad temp_max temp_min if binary_excess_1==0, mmqreg q(10,25,50,75,90) abs(region_est3 year) cluster(region_est3)

* --- Plot (Figure 17)

mmqreg log_ila i.sector#c.index2 i.estado_civil i.hombre edad temp_max temp_min if binary_excess_1==0, q(50) abs(region_est3 year) cluster(region_est3)
qregplot, estore(ila_deficit)
qregplot 1.sector#c.index2, from(ila_deficit) name(ila_deficit_primary, replace) title("Primary")
qregplot 2.sector#c.index2, from(ila_deficit) name(ila_deficit_secondary, replace) title("Secondary")
qregplot 3.sector#c.index2, from(ila_deficit) name(ila_deficit_tertiary, replace) title("Tertiary")
graph combine ila_deficit_primary ila_deficit_secondary ila_deficit_tertiary, col(3)
graph export "C:\Users\q33044\Desktop\Research\Revision_Ecuador_WD\Figures\qregplot_ila_deficit.pdf", replace

* --- Household income (ipcf) (Table 4)

qregfe log_ipcf c.index2 i.estado_civil i.hombre edad temp_max temp_min if binary_excess_1==0, mmqreg q(10,25,50,75,90) abs(region_est3 year) cluster(region_est3)

qregfe log_ipcf i.sector#c.index2 i.estado_civil i.hombre edad temp_max temp_min if binary_excess_1==0, mmqreg q(10,25,50,75,90) abs(region_est3 year) cluster(region_est3)

* --- Plot (Figure 17)

mmqreg log_ipcf i.sector#c.index2 i.estado_civil i.hombre edad temp_max temp_min if binary_excess_1==0, q(50) abs(region_est3 year) cluster(region_est3)
qregplot, estore(ipcf_deficit)
qregplot 1.sector#c.index2, from(ipcf_deficit) name(ipcf_deficit_primary, replace) title("Primary")
qregplot 2.sector#c.index2, from(ipcf_deficit) name(ipcf_deficit_secondary, replace) title("Secondary")
qregplot 3.sector#c.index2, from(ipcf_deficit) name(ipcf_deficit_tertiary, replace) title("Tertiary")
graph combine ipcf_deficit_primary ipcf_deficit_secondary ipcf_deficit_tertiary, col(3)
graph export "C:\Users\q33044\Desktop\Research\Revision_Ecuador_WD\Figures\qregplot_ipcf_deficit.pdf", replace

