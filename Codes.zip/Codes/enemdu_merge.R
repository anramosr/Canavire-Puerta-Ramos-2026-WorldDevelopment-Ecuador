rm(list=ls())
library(data.table)
library(dplyr)
library(readxl)
library(labelled)
library(haven)
library(rgdal)

setwd("C:/Users/q33044/Desktop/Research/Revision_Ecuador_WD/") # Set your own working directory

# Economic Data
enemdu2007_24 <- read_dta("Input/0_enemdu2007_24.dta")
vars<-c("year", "area", "ciudad", "panelm", "vivienda", "hogar", "p01", "p02", "p03", "p04", "p06", "edu", "skills",  "formal", "firmS_3", "pobreza", "epobreza", "ecSec","ingpcPPP", "pc_la_PPP" ) # Selected variables for the econometric analysis
Data<-select(enemdu2007_24,all_of(vars))
names(Data) <- c("year", "urbano", "region_est3", "panelm", "vivienda", "hogar", "p01", "hombre", "edad", "jefe", "estado_civil", "aedu", "skills",  "formal", "firmS_3", "poorEC", "epobreza", "ecSec","ipcf", "ila") # Re-name variables
Data<-filter(Data,jefe==1,edad %in% c(18:65))
Data$region_est3<-as.character(Data$region_est3)

# Precipitation Data
Data_precipitation<-read_excel("Data/annual_precipitation.xlsx")

# Temperature Data

temp_ecuador <- read_dta("Input/precip_ecuador2007_24.dta")
average_by_year_parish <- temp_ecuador %>%
  group_by(CODIGOP, year) %>%           # Group by unit and year
  summarise(temp_max = mean(temp_max, na.rm = TRUE), temp_min = mean(temp_min, na.rm = TRUE)) %>%  # Compute mean
  ungroup()
 
# Merge both datasets

regions<-intersect(unique(Data_precipitation$CC_3),unique(Data$region_est3))
Data<-filter(Data, region_est3 %in% regions, year %in% unique(Data_precipitation$year))
colnames(Data_precipitation)[colnames(Data_precipitation)=="CC_3"]<-"region_est3"
Data<-merge(Data, Data_precipitation, by=c("region_est3","year"))

merged_data <- left_join(Data, average_by_year_parish, by = c("region_est3" = "CODIGOP", "year" = "year"))

# Save the merged data
fwrite(merged_data,"Data/Data_estimation_rev.csv")

