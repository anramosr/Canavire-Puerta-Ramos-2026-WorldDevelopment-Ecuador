rm(list=ls())
library(data.table)
library(haven)
library(dplyr)
library(fixest)
library(parallel)
library(ggplot2)
library(ggpubr)
library(tidyr)
library(knitr)
library(kableExtra)
library(stargazer)
library(xtable)
library(stringr)

setwd("C:/Users/q33044/Desktop/Research/Revision_Ecuador_WD") # Set your own working directory
Data<-fread("Data/Data_estimation_rev.csv")
Data$categ_lab<-Data$formal
Data$sector1d<-Data$ecSec
group1<-c(2,6) #Agriculture and Mining
group2<-c(4,5) # Construction and Manufacturing
group3<-c(1,3) # Services and Commerce
Data$sector<-ifelse(Data$sector%in% group1,'Primary',
                    Data$sector)
Data$sector<-ifelse(Data$sector %in% group2,'Secondary',
                    Data$sector)
Data$sector<-ifelse(Data$sector %in% group3,'Tertiary',Data$sector)

# Table 1: Descriptive statistics
Sum_stats<-lapply(1:3, function(mm){
  Data$married<-NA
  Data$married<-ifelse(Data$estado_civil==1,1,0) # Married
  Data$self_employed<-ifelse(Data$firmS_3==1,1,0) # Self Employed
  if(mm==1){
    primary_data <- Data %>% filter(sector == "Primary")
  } else if (mm==2) {
    primary_data <- Data %>% filter(sector == "Secondary")
  } else {
    primary_data <- Data %>% filter(sector == "Tertiary")
  }
  overall_summary <- primary_data %>%
    summarise(
      N = n(),
      mean_income = mean(ipcf, na.rm = TRUE),
      median_income = median(ipcf, na.rm = TRUE),
      sd_income = sd(ipcf, na.rm = TRUE),
      min_income = min(ipcf, na.rm = TRUE),
      max_income = max(ipcf, na.rm = TRUE),
      mean_lab_income = mean(ila, na.rm = TRUE),
      median_lab_income = median(ila, na.rm = TRUE),
      sd_lab_income = sd(ila, na.rm = TRUE),
      min_lab_income = min(ila, na.rm = TRUE),
      max_lab_income = max(ila, na.rm = TRUE),
      mean_age = mean(edad, na.rm = TRUE),
      poverty_rate = mean(poorEC, na.rm = TRUE) * 100,
      marriage_rate = mean(married, na.rm = TRUE) * 100
    ) %>%
    pivot_longer(everything(), names_to = "Statistic", values_to = "All_Workers")
  
  # Step 2: Summary by Urban / Rural
  urban_summary <- primary_data %>%
    group_by(urbano) %>%
    summarise(
      N = n(),
      mean_income = mean(ipcf, na.rm = TRUE),
      median_income = median(ipcf, na.rm = TRUE),
      sd_income = sd(ipcf, na.rm = TRUE),
      min_income = min(ipcf, na.rm = TRUE),
      max_income = max(ipcf, na.rm = TRUE),
      mean_lab_income = mean(ila, na.rm = TRUE),
      median_lab_income = median(ila, na.rm = TRUE),
      sd_lab_income = sd(ila, na.rm = TRUE),
      min_lab_income = min(ila, na.rm = TRUE),
      max_lab_income = max(ila, na.rm = TRUE),
      mean_age = mean(edad, na.rm = TRUE),
      poverty_rate = mean(poorEC, na.rm = TRUE) * 100,
      marriage_rate = mean(married, na.rm = TRUE) * 100
    ) %>%
    pivot_longer(cols = -urbano, names_to = "Statistic", values_to = "Value") %>%
    pivot_wider(names_from = urbano, values_from = Value)
  
  # Step 3: Summary by Formal / Informal
  formal_summary <- primary_data %>%
    group_by(categ_lab) %>%
    summarise(
      N = n(),
      mean_income = mean(ipcf, na.rm = TRUE),
      median_income = median(ipcf, na.rm = TRUE),
      sd_income = sd(ipcf, na.rm = TRUE),
      min_income = min(ipcf, na.rm = TRUE),
      max_income = max(ipcf, na.rm = TRUE),
      mean_lab_income = mean(ila, na.rm = TRUE),
      median_lab_income = median(ila, na.rm = TRUE),
      sd_lab_income = sd(ila, na.rm = TRUE),
      min_lab_income = min(ila, na.rm = TRUE),
      max_lab_income = max(ila, na.rm = TRUE),
      mean_age = mean(edad, na.rm = TRUE),
      poverty_rate = mean(poorEC, na.rm = TRUE) * 100,
      marriage_rate = mean(married, na.rm = TRUE) * 100
    ) %>%
    pivot_longer(cols = -categ_lab, names_to = "Statistic", values_to = "Value") %>%
    pivot_wider(names_from = categ_lab, values_from = Value)
  
  # Step 4: Summary by Self-Employed / Not Self-Employed
  selfemp_summary <- primary_data %>%
    group_by(self_employed) %>%
    summarise(
      N = n(),
      mean_income = mean(ipcf, na.rm = TRUE),
      median_income = median(ipcf, na.rm = TRUE),
      sd_income = sd(ipcf, na.rm = TRUE),
      min_income = min(ipcf, na.rm = TRUE),
      max_income = max(ipcf, na.rm = TRUE),
      mean_lab_income = mean(ila, na.rm = TRUE),
      median_lab_income = median(ila, na.rm = TRUE),
      sd_lab_income = sd(ila, na.rm = TRUE),
      min_lab_income = min(ila, na.rm = TRUE),
      max_lab_income = max(ila, na.rm = TRUE),
      mean_age = mean(edad, na.rm = TRUE),
      poverty_rate = mean(poorEC, na.rm = TRUE) * 100,
      marriage_rate = mean(married, na.rm = TRUE) * 100
    ) %>%
    pivot_longer(cols = -self_employed, names_to = "Statistic", values_to = "Value") %>%
    pivot_wider(names_from = self_employed, values_from = Value)
  
  # Step 5: Combine all summaries into one table
  final_table <- overall_summary %>%
    left_join(urban_summary, by = "Statistic") %>%
    left_join(formal_summary, by = "Statistic") %>%
    left_join(selfemp_summary, by = "Statistic")
  
  # Rename columns for clarity
  colnames(final_table) <- c("Statistic", "All Workers", "Rural", "Urban", "Informal","Formal",
                             "Not Self-Employed","Self-Employed")
  
  # Optional: Round numeric values to 2 decimals, keep N as integer
  final_table <- final_table %>%
    mutate(across(-Statistic, ~ifelse(Statistic == "N", round(.), round(., 2))))
  
})
# Table 1
xtable(t(Sum_stats[[1]])) # Primary sector
xtable(t(Sum_stats[[2]])) # Secondary sector
xtable(t(Sum_stats[[3]])) # Tertiary sector
table(Data$categ_lab, ifelse(Data$firmS_3==1, 1, 0))
table(Data$categ_lab, ifelse(Data$firmS_3==1, 1, 0), by = Data$sector)

# Econometric models

dep_vars<-c("lipcf","lila","poorEC")
names_dep<-c("Per Capita Household Income","Labor Income","Poverty Rate")
ops<-c("Excess","Deficit")
Data$lipcf<-log(Data$ipcf+1)
Data$lila<-log(Data$ila+1)
controls<-c("as.factor(estado_civil)","hombre","edad", "temp_max", "temp_min")
Data$region_est3<-as.character(Data$region_est3)
Data$region_est3<-ifelse(nchar(Data$region_est3)==5,paste0("0",Data$region_est3),
                         Data$region_est3)
Data$region_est2<-substr(Data$region_est3,1,4)
Data$region_est1<-substr(Data$region_est3,1,2)

Graph <- lapply(1:3, function(k){   # loop over quantile sets
  lapply(1:length(dep_vars), function(i){
    
    Both <- lapply(1:length(ops), function(j){
      if (ops[j] == "Excess") {
        Dat <- Data[-which(Data[[paste0("binary_deficit_", k)]] == 1), ]
        Dat$index <- Dat[[paste0("binary_excess_", k)]]
      } else {
        Dat <- Data[-which(Data[[paste0("binary_excess_", k)]] == 1), ]
        Dat$index <- Dat[[paste0("binary_deficit_", k)]]
      }
      
      model0 <- formula(paste0(dep_vars[i], "~ index +", 
                               paste0(controls, collapse = "+"),
                               "|region_est3 + year"))
      model1 <- formula(paste0(dep_vars[i], "~i(sector, index)+", 
                               paste0(controls, collapse = "+"),
                               "|region_est3 + year"))
      
      res0 <- summary(feols(model0, Dat, vcov = "clust"))
      res1 <- summary(feols(model1, Dat, vcov = "clust"))
      
      # Add nobs to res0 results
      CIs0 <- do.call(cbind, lapply(c(0.9,0.95), function(lvl){
        confint(res0, level = lvl)[1, ]
      }))
      CIs0 <- cbind(coef = res0$coefficients[1], CIs0, nobs = res0$nobs)
      
      # Add nobs to res1 results
      CIs <- do.call(cbind, lapply(c(0.9,0.95), function(lvl){
        confint(res1, level = lvl)[1:3, ]
      }))
      CIs <- cbind(coef = res1$coefficients[1:3], CIs, nobs = res1$nobs)
      
      res <- rbind(CIs0, CIs)
      labs_graph <- rownames(res)
      labs_graph <- ifelse(nchar(labs_graph) > 5,
                           substring(labs_graph, 9, nchar(labs_graph) - 6),
                           "All")
      
      dat_graph <- data.frame(res, clust = labs_graph)
      colnames(dat_graph)[1:6] <- c("coef","lower_10","upper_10","lower_5","upper_5","nobs")
      dat_graph$clust <- factor(dat_graph$clust, 
                                levels = c("All","Primary","Secondary","Tertiary"))
      dat_graph$ops <- ops[j]
      return(dat_graph)
    })
    
    dat_graph <- rbind(Both[[1]], Both[[2]])
    
    graph <- ggplot(data = dat_graph, aes(x = ops, y = coef)) + 
      facet_wrap(~clust, strip.position = "bottom", scales = "free_x", ncol = 4) +
      geom_errorbar(aes(ymin = lower_10 , ymax =  upper_10, color = '90 % C.I'),
                    position = position_dodge(width = 1), width = 0.4, size = 0.7) +
      geom_errorbar(aes(ymin = lower_5 , ymax =  upper_5, color = '95 % C.I'),
                    position = position_dodge(width = 1), width = 0.5, size = 0.7) +
      geom_point(position = position_dodge(width = 0.8), shape = 22, size = 12, aes(fill = ops)) +
      scale_fill_manual(values = c('black', 'grey'), name = "") +
      theme_bw() +
      xlab("") + ggtitle("") +
      ylab("Effect") +
      geom_hline(yintercept = 0, linetype = 'dotted', col = 'black', size = 0.8) +
      theme(plot.title = element_text(hjust = 0.5)) +
      scale_color_manual(name = '',
                         values = c('95 % C.I' = 'black','90 % C.I' = 'grey')) +
      theme(plot.title = element_text(hjust = 0.5, size = 37),
            axis.title.x = element_text(size = 30),
            axis.title.y = element_text(size = 40),
            axis.text.y = element_text(face = "bold", size = 35),
            legend.text = element_text(size = 37),
            legend.title = element_text(""),
            axis.text.x = element_text(face = "bold", size = 35),
            legend.key.height = unit(2, "cm"),
            strip.text.x = element_text(size = 45),
            strip.placement = "outside")
    return(list(graph = graph, data = dat_graph))
  })
})
all_data <- list()  # to store all dat_graph tables

## Figures 3,7, and 12 
for (k in 1:3) {
  for (i in seq_along(dep_vars)) {
    setwd("C:/Users/q33044/Desktop/Research/Revision_Ecuador_WD/Figures") # Set your own working directory
    # Extract graph and data
    g <- Graph[[k]][[i]]$graph
    dat <- Graph[[k]][[i]]$data
    
    # Build filename with dep var name + quantile index
    fname <- paste0(dep_vars[i], "_qset", k, ".pdf")
    
    # Save graph without displaying
    if(k==1){
      ggsave(fname, plot = g, width = 25, height = 11)
    }
    
    # Store dat_graph with identifiers
    dat$dep_var <- dep_vars[i]
    dat$qset <- k
    all_data[[paste0(dep_vars[i], "_qset", k)]] <- dat
  }
}

## Tables A1, A5, and A8

all_data_df <- do.call(rbind, all_data)
all_data_df <- all_data_df %>%
  mutate(
    qset = case_when(
      qset == 1 ~ "25",
      qset == 2 ~ "10",
      qset == 3 ~ "40",
      TRUE ~ as.character(qset)
    ),
    est_ci = paste0(sprintf("%.3f", coef),
                    " (", sprintf("%.3f", lower_5),
                    ", ", sprintf("%.3f", upper_5), ")")
  )
all_data_df<-select(all_data_df,-all_of(c("coef", "lower_10", "upper_10", "lower_5",  "upper_5")))%>%
arrange(qset,ops)
shocks<-c("Excess","Deficit")
qs<-c(10,25,40)
Tabs<-lapply(1:length(dep_vars), function(i){
  loc_dat<-filter(all_data_df,dep_var==dep_vars[i])
  res_loc_1<-do.call(rbind,lapply(1:length(shocks), function(j){
    loc_dat_1<-filter(loc_dat,ops==shocks[j])
    res_loc<-do.call(rbind,lapply(1:length(qs), function(k){
      loc_dat_2<-filter(loc_dat_1,qset==qs[k]) 
      all<-loc_dat_2[loc_dat_2$clust == "All", c("est_ci", "nobs")]
      rest<-c(loc_dat_2[loc_dat_2$clust=="Primary","est_ci"],
              loc_dat_2[loc_dat_2$clust=="Secondary","est_ci"],
              loc_dat_2[loc_dat_2$clust=="Tertiary","est_ci"],
              loc_dat_2[loc_dat_2$clust=="Primary","nobs"])
      res<-do.call(cbind,c(qs[k],all,rest))
    }))
  }))
})

print(xtable(Tabs[[3]]), include.rownames = FALSE) # Table A1
print(xtable(Tabs[[2]]), include.rownames = FALSE) # Table A3
print(xtable(Tabs[[1]]), include.rownames = FALSE) # Table A8

# Figures 4, 8 and 13

urb<-c("Rural","Urban")
Loop_arg<-expand.grid(c(2,1),c(2,1))
Fig3_dat<-lapply(1:3, function(m){ lapply(1:length(dep_vars), function(i){
  Graph<-lapply(1:dim(Loop_arg)[1], function(s){
    j<-Loop_arg[s,1]
    k<-Loop_arg[s,2]
    if(j==1){ Dat<-filter(Data,urbano!=1) 
    } else{  Dat<-filter(Data,urbano==1)}
    if(ops[k]=="Flood"){
      Dat <- Dat[-which(Dat[[paste0("binary_deficit_", m)]] == 1), ]
      Dat$index <- Dat[[paste0("binary_excess_", m)]] 
    } else{
      Dat <- Dat[-which(Dat[[paste0("binary_excess_", m)]] == 1), ]
      Dat$index <- Dat[[paste0("binary_deficit_", m)]]
    }
    model0<-formula(paste0(dep_vars[i],"~index+",paste0(controls,collapse = "+"),
                           "|region_est3+year"))
    model1<-formula(paste0(dep_vars[i],"~i(sector,index)+",
                           paste0(controls,collapse = "+"),
                           "|region_est3+year"))
    res0<-summary(feols(model0,Dat,vcov = "clust"))
    res1<-summary(feols(model1,Dat,vcov = "clust"))
    CIs0<-do.call(cbind,lapply(c(0.9,0.95),function(i){
      confint(res0, level=i)[1,]
    }))
    CIs0 <- cbind(coef = res0$coefficients[1], CIs0, nobs = res0$nobs)
    CIs<-do.call(cbind,lapply(c(0.9,0.95),function(i){
      confint(res1, level=i)[1:3,]
    }))
    CIs <- cbind(coef = res1$coefficients[1:3], CIs, nobs = res1$nobs)
    res<-rbind(CIs0,CIs)
    labs_graph<-rownames(res)
    labs_graph<-ifelse(nchar(labs_graph)>5,
                       substring(labs_graph,9,nchar(labs_graph)-6),"All")
    dat_graph<-data.frame(res,clust=labs_graph)
    colnames(dat_graph)<-c("coef","lower_10","upper_10","lower_5",
                           "upper_5","nobs","clust")
    dat_graph$clust<-factor(dat_graph$clust,levels=
                              c("All","Primary",
                                "Secondary","Tertiary"))
    dat_graph$ops<-ops[k]
    dat_graph$urban<-urb[j]
    return(dat_graph)})
  dat_graph<-do.call(rbind,Graph)
  graph<-ggplot(data = dat_graph, aes(x =ops, y = coef, fill = urban)) + 
    facet_wrap(~clust, strip.position = "bottom", scales = "free_x",ncol=4)+
    scale_fill_manual(values=c('black', 'grey'),name="")+
    geom_errorbar(aes(ymin = lower_10 , ymax =  upper_10,color='90 % C.I'),
                  position=position_dodge(width=0.8),width=0.4,size=0.7)+
    geom_errorbar(aes(ymin = lower_5 , ymax =  upper_5,color='95 % C.I'),
                  position=position_dodge(width=0.8),width=0.5,size=0.7)+ 
    geom_point(position=position_dodge(width=0.8),shape=22,size=8) +
    theme_bw()+
    xlab("")+ggtitle("")+
    ylab("Effect")+
    geom_hline(yintercept = 0,linetype='dotted', col = 'black',size=0.8)+
    theme(plot.title = element_text(hjust = 0.5))+
    scale_color_manual(name='',
                       values=c('95 % C.I'='black','90 % C.I'='grey'))+
    theme(plot.title = element_text(hjust = 0.5,size = 45),
          axis.title.x = element_text(size = 30),
          axis.title.y = element_text(size = 40),
          axis.text.y = element_text(face="bold", 
                                     size=35
          ),legend.text = element_text(size=37),
          legend.title = element_text(""),
          axis.text.x = element_text(face="bold", size=35),
          legend.key.height = unit(2, "cm"),
          strip.text.x = element_text(size = 45),
          strip.placement = "outside")
  return(list(graph = graph, data = dat_graph)) })})
all_data_ur <- list()
for (k in 1:3) {
  for (i in seq_along(dep_vars)) {
    setwd("C:/Users/q33044/Desktop/Research/Revision_Ecuador_WD/Figures") # Set your own working directory
        # Extract graph and data
    g <- Fig3_dat[[k]][[i]]$graph
    dat <- Fig3_dat[[k]][[i]]$data
    
    # Build filename with dep var name + quantile index
    fname <- paste0("urb_rur",dep_vars[i], "_qset", k, ".pdf")
    
    # Save graph without displaying
    if(k==1){
    ggsave(fname, plot = g, width = 25, height = 11)
    }
    
    # Store dat_graph with identifiers
    dat$dep_var <- dep_vars[i]
    dat$qset <- k
    all_data_ur[[paste0(dep_vars[i], "_qset", k)]] <- dat
  }
}
all_data_ur_df <- do.call(rbind, all_data_ur)
all_data_ur_df <- all_data_ur_df %>%
  mutate(
    qset = case_when(
      qset == 1 ~ "25",
      qset == 2 ~ "10",
      qset == 3 ~ "40",
      TRUE ~ as.character(qset)
    ),
    est_ci = paste0(sprintf("%.3f", coef),
                    " (", sprintf("%.3f", lower_5),
                    ", ", sprintf("%.3f", upper_5), ")"))
all_ur<-filter(all_data_ur_df,dep_var=="poorEC")
Tab_urb_rur<-do.call(rbind,lapply(1:length(shocks), function(i){
  loc_dat<-filter(all_ur,ops==shocks[i])
  res_loc_1<-do.call(rbind,lapply(1:length(urb), function(j){
    loc_dat_1<-filter(loc_dat,urban==urb[j])
    res_loc<-do.call(rbind,lapply(1:length(qs), function(k){
      loc_dat_2<-filter(loc_dat_1,qset==qs[k]) 
      all<-loc_dat_2[loc_dat_2$clust == "All", c("est_ci", "nobs")]
      rest<-c(loc_dat_2[loc_dat_2$clust=="Primary","est_ci"],
              loc_dat_2[loc_dat_2$clust=="Secondary","est_ci"],
              loc_dat_2[loc_dat_2$clust=="Tertiary","est_ci"],
              loc_dat_2[loc_dat_2$clust=="Primary","nobs"])
      res<-do.call(cbind,c(qs[k],all,rest))
    }))
  }))
}))
print(xtable(Tab_urb_rur), include.rownames = FALSE) # Table A2

# Figures 5, 9, and 14

formal<-c("Informal","Formal")
Loop_arg<-expand.grid(c(1,2),c(1,2))
Graph4<-lapply(1:length(dep_vars), function(i){
  lapply(1:2, function(m){
    if(m==1){
      Dat <- Data[-which(Data[[paste0("binary_deficit_", 1)]] == 1), ]
      Dat$index <- Dat[[paste0("binary_excess_", 1)]] 
    } else{
      Dat <- Data[-which(Data[[paste0("binary_excess_", 1)]] == 1), ]
      Dat$index <- Dat[[paste0("binary_deficit_", 1)]]
    }
    Graph<-lapply(1:dim(Loop_arg)[1], function(s){
      j<-Loop_arg[s,1]
      k<-Loop_arg[s,2]
      if(k==1){
        Dat<-filter(Dat,urbano!=1) # 1 = Rural
      } else{
        Dat<-filter(Dat,urbano==1)
      }
      if(j==1){ Dat<-filter(Dat,categ_lab==1) # 1 = Formal
      } else { Dat<-filter(Dat,categ_lab!=1)}
      model0<-formula(paste0(dep_vars[i],"~index+",paste0(controls,collapse = "+"),
                             "|region_est3+year"))
      model1<-formula(paste0(dep_vars[i],"~i(sector,index)+",
                             paste0(controls,collapse = "+"),
                             "|region_est3+year"))
      res0<-summary(feols(model0,Dat,vcov = "clust"))
      res1<-summary(feols(model1,Dat,vcov = "clust"))
      CIs0<-do.call(cbind,lapply(c(0.9,0.95),function(i){
        confint(res0, level=i)[1,]
      }))
      CIs0 <- cbind(coef = res0$coefficients[1], CIs0, nobs = res0$nobs)
      CIs<-do.call(cbind,lapply(c(0.9,0.95),function(i){
        confint(res1, level=i)[1:3,]
      }))
      CIs <- cbind(coef = res1$coefficients[1:3], CIs, nobs = res1$nobs)
      res<-rbind(CIs0,CIs)
      labs_graph<-rownames(res)
      labs_graph<-ifelse(nchar(labs_graph)>5,
                         substring(labs_graph,9,nchar(labs_graph)-6),"All")
      dat_graph<-data.frame(res,clust=labs_graph)
      colnames(dat_graph)<-c("coef","lower_10","upper_10","lower_5",
                             "upper_5","nobs","clust")
      dat_graph$clust<-factor(dat_graph$clust,levels=
                                c("All","Primary",
                                  "Secondary","Tertiary"))
      dat_graph$ops<-ops[m]
      dat_graph$urban<-urb[k]
      dat_graph$formal<-formal[j]
      return(dat_graph)})
    dat_graph<-do.call(rbind,Graph)
    graph<-ggplot(data = dat_graph, aes(x = urban, y = coef, fill = formal)) + 
      facet_wrap(~clust, strip.position = "bottom", scales = "free_x",ncol=4)+
      scale_fill_manual(values = c('black', 'grey'),name="")+
      geom_errorbar(aes(ymin = lower_10 , ymax =  upper_10,color='90 % C.I'),
                    position=position_dodge(width=0.8),width=0.4,size=1.4)+
      geom_errorbar(aes(ymin = lower_5 , ymax =  upper_5,color='95 % C.I'),
                    position=position_dodge(width=0.8),width=0.5,size=1.4)+ 
      geom_point(position=position_dodge(width=0.8),shape=22,size=20) +
      theme_bw()+
      xlab("")+ggtitle(ifelse(m==1,"Excess","Deficit"))+
      ylab("Effect")+
      geom_hline(yintercept = 0,linetype='dotted', col = 'black',size=0.8)+
      theme(plot.title = element_text(hjust = 0.5))+
      scale_color_manual(name='',
                         values=c('95 % C.I'='black','90 % C.I'='grey'))+
      theme(plot.title = element_text(hjust = 0.5,size = 45),
            axis.title.x = element_text(size = 30),
            axis.title.y = element_text(size = 40),
            axis.text.y = element_text(face="bold", 
                                       size=35
            ),legend.text = element_text(size=37),
            legend.title = element_text(""),
            axis.text.x = element_text(face="bold", size=35),
            legend.key.height = unit(2, "cm"),
            strip.text.x = element_text(size = 45),
            strip.placement = "outside")
    return(list(graph = graph, data = dat_graph))})})
Graph4[[3]][[1]]$graph
ggsave("poverty_flood.pdf", width = 40, height = 18)
Graph4[[3]][[2]]$graph
ggsave("poverty_drought.pdf", width = 40, height = 18)
Graph4[[2]][[1]]$graph
ggsave("lab_income_flood.pdf", width = 40, height = 18)
Graph4[[2]][[2]]$graph
ggsave("lab_income_drought.pdf", width = 40, height = 18)
Graph4[[1]][[1]]$graph
ggsave("hh_income_flood.pdf", width = 40, height = 18)
Graph4[[1]][[2]]$graph
ggsave("hh_income_drought.pdf", width = 40, height = 18)

# Table A3
Tables_formal <-lapply(1:3, function(i) {
  do.call(rbind,lapply(1:2, function(k) {
    do.call(rbind, lapply(Graph4[[i]][[k]], function(x) x$data))
  }))
})
Tabs_formal<-lapply(1:3, function(mm){
  pov_formal<-Tables_formal[[mm]]
  pov_formal <- pov_formal %>%
    mutate(est_ci = paste0(sprintf("%.3f", coef),
                           " (", sprintf("%.3f", lower_5),
                           ", ", sprintf("%.3f", upper_5), ")"))
  formals<-formal
  Tab_formal<-do.call(rbind,lapply(1:length(shocks), function(i){
    loc_dat<-filter(pov_formal,ops==shocks[i])
    res_loc_1<-do.call(rbind,lapply(1:length(urb), function(j){
      loc_dat_1<-filter(loc_dat,urban==urb[j])
      res_loc<-do.call(rbind,lapply(1:length(formal), function(k){
        loc_dat_2<-filter(loc_dat_1,formal==formals[k]) 
        all<-loc_dat_2[loc_dat_2$clust == "All", c("est_ci", "nobs")]
        rest<-c(loc_dat_2[loc_dat_2$clust=="Primary","est_ci"],
                loc_dat_2[loc_dat_2$clust=="Secondary","est_ci"],
                loc_dat_2[loc_dat_2$clust=="Tertiary","est_ci"],
                loc_dat_2[loc_dat_2$clust=="Primary","nobs"])
        res<-do.call(cbind,c(formals[k],all,rest))
      }))
    }))
  }))
})

print(xtable(Tabs_formal[[3]]), include.rownames = FALSE) # Table A3

# Figures 5, 9, and 14

employed<-c("Self-employed","Not Self-employed")
Loop_arg<-expand.grid(c(1,2),c(1,2))
Graph5<-lapply(1:length(dep_vars), function(i){
  lapply(1:2, function(m){
    if(m==1){
      Dat <- Data[-which(Data[[paste0("binary_deficit_", 1)]] == 1), ]
      Dat$index <- Dat[[paste0("binary_excess_", 1)]] 
    } else{
      Dat <- Data[-which(Data[[paste0("binary_excess_", 1)]] == 1), ]
      Dat$index <- Dat[[paste0("binary_deficit_", 1)]]
    }
    Graph<-lapply(1:dim(Loop_arg)[1], function(s){
      j<-Loop_arg[s,1]
      k<-Loop_arg[s,2]
      if(k==1){
        Dat<-filter(Dat,firmS_3==1) # 1 = Self-Employed
      } else{
        Dat<-filter(Dat,firmS_3!=1)
      }
      if(j==1){ Dat<-filter(Dat,categ_lab==1) 
      } else { Dat<-filter(Dat,categ_lab!=1)}
      model0<-formula(paste0(dep_vars[i],"~index+",paste0(controls,collapse = "+"),
                             "|region_est3+year"))
      model1<-formula(paste0(dep_vars[i],"~i(sector,index)+",
                             paste0(controls,collapse = "+"),
                             "|region_est3+year"))
      res0<-summary(feols(model0,Dat,vcov = "clust"))
      res1<-summary(feols(model1,Dat,vcov = "clust"))
      CIs0<-do.call(cbind,lapply(c(0.9,0.95),function(i){
        confint(res0, level=i)[1,]
      }))
      CIs0 <- cbind(coef = res0$coefficients[1], CIs0, nobs = res0$nobs)
      CIs<-do.call(cbind,lapply(c(0.9,0.95),function(i){
        confint(res1, level=i)[1:3,]
      }))
      CIs <- cbind(coef = res1$coefficients[1:3], CIs, nobs = res1$nobs)
      res<-rbind(CIs0,CIs)
      labs_graph<-rownames(res)
      labs_graph<-ifelse(nchar(labs_graph)>5,
                         substring(labs_graph,9,nchar(labs_graph)-6),"All")
      dat_graph<-data.frame(res,clust=labs_graph)
      colnames(dat_graph)<-c("coef","lower_10","upper_10","lower_5",
                             "upper_5","nobs","clust")
      dat_graph$clust<-factor(dat_graph$clust,levels=
                                c("All","Primary",
                                  "Secondary","Tertiary"))
      dat_graph$ops<-ops[m]
      dat_graph$urban<-urb[k]
      dat_graph$employed<-employed[j]
      return(dat_graph)})
    dat_graph<-do.call(rbind,Graph)
    graph<-ggplot(data = dat_graph, aes(x = urban, y = coef, fill = employed)) + 
      facet_wrap(~clust, strip.position = "bottom", scales = "free_x",ncol=4)+
      scale_fill_manual(values = c('black', 'grey'),name="")+
      geom_errorbar(aes(ymin = lower_10 , ymax =  upper_10,color='90 % C.I'),
                    position=position_dodge(width=0.8),width=0.4,size=1.4)+
      geom_errorbar(aes(ymin = lower_5 , ymax =  upper_5,color='95 % C.I'),
                    position=position_dodge(width=0.8),width=0.5,size=1.4)+ 
      geom_point(position=position_dodge(width=0.8),shape=22,size=20) +
      theme_bw()+
      xlab("")+ggtitle(ifelse(m==1,"Excess","Deficit"))+
      ylab("Effect")+
      geom_hline(yintercept = 0,linetype='dotted', col = 'black',size=0.8)+
      theme(plot.title = element_text(hjust = 0.5))+
      scale_color_manual(name='',
                         values=c('95 % C.I'='black','90 % C.I'='grey'))+
      theme(plot.title = element_text(hjust = 0.5,size = 45),
            axis.title.x = element_text(size = 30),
            axis.title.y = element_text(size = 40),
            axis.text.y = element_text(face="bold", 
                                       size=35
            ),legend.text = element_text(size=37),
            legend.title = element_text(""),
            axis.text.x = element_text(face="bold", size=35),
            legend.key.height = unit(2, "cm"),
            strip.text.x = element_text(size = 45),
            strip.placement = "outside")
    return(list(graph = graph, data = dat_graph))})})
Graph5[[3]][[1]]$graph
ggsave("poverty_flood_self.pdf", width = 40, height = 18)
Graph5[[3]][[2]]$graph
ggsave("poverty_drought_self.pdf", width = 40, height = 18)
Graph5[[2]][[1]]$graph
ggsave("lab_income_flood_self.pdf", width = 40, height = 18)
Graph5[[2]][[2]]$graph
ggsave("lab_income_drought_self.pdf", width = 40, height = 18)
Graph5[[1]][[1]]$graph
ggsave("hh_income_flood_self.pdf", width = 40, height = 18)
Graph5[[1]][[2]]$graph
ggsave("hh_income_drought_self.pdf", width = 40, height = 18)
Tables_self <-lapply(1:3, function(i) {
  do.call(rbind,lapply(1:2, function(k) {
    do.call(rbind, lapply(Graph5[[i]][[k]], function(x) x$data))
  }))
})

Tabs_se<-lapply(1:3, function(mm){
  pov_self<-Tables_self[[mm]]
  pov_se <- pov_self %>%
    mutate(est_ci = paste0(sprintf("%.3f", coef),
                           " (", sprintf("%.3f", lower_5),
                           ", ", sprintf("%.3f", upper_5), ")"))
  employeds<-employed
  Tab_se<-do.call(rbind,lapply(1:length(shocks), function(i){
    loc_dat<-filter(pov_se,ops==shocks[i])
    res_loc_1<-do.call(rbind,lapply(1:length(urb), function(j){
      loc_dat_1<-filter(loc_dat,urban==urb[j])
      res_loc<-do.call(rbind,lapply(1:length(employed), function(k){
        loc_dat_2<-filter(loc_dat_1,employed==employeds[k]) 
        all<-loc_dat_2[loc_dat_2$clust == "All", c("est_ci", "nobs")]
        rest<-c(loc_dat_2[loc_dat_2$clust=="Primary","est_ci"],
                loc_dat_2[loc_dat_2$clust=="Secondary","est_ci"],
                loc_dat_2[loc_dat_2$clust=="Tertiary","est_ci"],
                loc_dat_2[loc_dat_2$clust=="Primary","nobs"])
        res<-do.call(cbind,c(employeds[k],all,rest))
      }))
    }))
  }))
})

## Table A4
print(xtable(Tabs_se[[3]]), include.rownames = FALSE)
## Table A5 
print(xtable(Tabs[[2]]), include.rownames = FALSE)
## Table A6
print(xtable(Tabs_formal[[2]]), include.rownames = FALSE)
## Table A7
print(xtable(Tabs_se[[2]]), include.rownames = FALSE)
## Table A8 
print(xtable(Tabs[[1]]), include.rownames = FALSE)
## Table A9
print(xtable(Tabs_formal[[1]]), include.rownames = FALSE)
## Table A10
print(xtable(Tabs_se[[1]]), include.rownames = FALSE)

## Lagged Impacts
Data <- Data %>%
  arrange(region_est3, year) %>% # sort by panel and time
  group_by(region_est3) %>%      # panel identifier
  mutate(
    binary_deficit_1_l = lag(binary_deficit_1, n = 1),  
    binary_excess_1_l = lag(binary_excess_1,  n = 1),
    binary_deficit_2_l = lag(binary_deficit_2, n = 1),  
    binary_excess_2_l = lag(binary_excess_2,  n = 1),
    binary_deficit_3_l = lag(binary_deficit_3, n = 1),  
    binary_excess_3_l = lag(binary_excess_3,  n = 1),
  ) %>%
  ungroup()
Lagged_Impacts <- lapply(c(2,1,3), function(i){
  
  Both <- lapply(1:length(ops), function(j){
    if (ops[j] == "Excess") {
      Dat <- Data[-which(Data[[paste0("binary_deficit_", 1)]] == 1), ]
      Dat$index   <- Dat[[paste0("binary_excess_", 1)]]
      Dat$index_l <- Dat[[paste0("binary_excess_", 1,"_l")]]
    } else {
      Dat <- Data[-which(Data[[paste0("binary_excess_", 1)]] == 1), ]
      Dat$index   <- Dat[[paste0("binary_deficit_", 1)]]
      Dat$index_l <- Dat[[paste0("binary_deficit_", 1,"_l")]]
    }
    model1_0 <- formula(paste0(dep_vars[i], 
                               "~ i(sector, index) +", 
                               paste0(controls, collapse = "+"),
                               "|region_est3 + year"))
    model1_1 <- formula(paste0(dep_vars[i], 
                               "~ i(sector, index) + i(sector, index_l) +", 
                               paste0(controls, collapse = "+"),
                               "|region_est3 + year"))
    model1_2 <- formula(paste0(dep_vars[i],
                               "~i(sector, index) + i(sector, index_l) + i(sector, index):i(sector, index_l) + ",
                               paste0(controls, collapse = "+"),
                               "|region_est3 + year"))
    
    res1_0 <- feols(model1_0, Dat, vcov = "clust")
    res1_1 <- feols(model1_1, Dat, vcov = "clust")
    res1_2 <- feols(model1_2, Dat, vcov = "clust")
    return(list(res1_0=res1_0,res1_1=res1_1,res1_2=res1_2))
  })
  sum_res<-etable(Both[[1]]$res1_0,Both[[1]]$res1_1,Both[[1]]$res1_2,
                  Both[[2]]$res1_0,Both[[2]]$res1_1,Both[[2]]$res1_2,
                  se = "cluster",
                  tex = TRUE,
                  drop = controls   # this will omit all variables in the 'controls' vector
  )
  return(sum_res)
})

print(Lagged_Impacts[[3]])

# Figure 11
avg_by_group <- Data %>%
  group_by(year, poorEC) %>%
  summarise(
    mean_lab = mean(ila, na.rm = TRUE),
    mean_hh = mean(ipcf, na.rm = TRUE),
    .groups = "drop"
  ) %>%
mutate(ratio = mean_lab / mean_hh)

avg_all <- Data %>%
  group_by(year) %>%
  summarise(
    mean_lab = mean(ila, na.rm = TRUE),
    mean_hh = mean(ipcf, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(ratio = mean_lab / mean_hh,
         poverty = "all")

figure11_data  <- bind_rows(
  avg_by_group %>% mutate(poverty = ifelse(poorEC == 1, "poor", "non-poor")), avg_all
)


ggplot(figure11_data[which(figure11_data$poverty!="NA"),], aes(x = year, y = ratio, color = poverty, linetype = poverty)) +
  geom_line(size = 1) +
  geom_point(size = 2) +
  scale_color_manual(values = c("poor" = "#E64B35", 
                                "non-poor" = "#4DBBD5", 
                                "all" = "#00A087")) +
  scale_linetype_manual(values = c("poor" = "solid", 
                                   "non-poor" = "solid", 
                                   "all" = "solid")) +
  labs(
    x = "",
    y = "",
    color = "Group",
    linetype = "Group"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.9, face = "bold"),
    legend.position = "bottom",
    legend.title = element_blank()
  )
ggsave("labor_household_share.png")

# Robustness (Figures A1, A2, A3, A4, A5, A6)
Data$region_est3<-as.character(Data$region_est3)
Data$region_est3<-ifelse(nchar(Data$region_est3)==5,paste0("0",Data$region_est3),
                         Data$region_est3)
Data$region_est2<-substr(Data$region_est3,1,4)
Data$region_est1<-substr(Data$region_est3,1,2)
region_levels <- c("region_est3","region_est1")
Loop_arg<-expand.grid(c(1,2),c(1,2))
Rob_tt_dat<-lapply(1:length(dep_vars), function(i){
  Graph<-lapply(1:dim(Loop_arg)[1], function(s){
    j<-Loop_arg[s,1]
    k<-Loop_arg[s,2]
    region<-region_levels[j]
    if(ops[k]=="Flood"){
      Dat <- Data[-which(Data[[paste0("binary_deficit_", 1)]] == 1), ]
      Dat$index <- Dat[[paste0("binary_excess_", 1)]] 
    } else{
      Dat <- Data[-which(Data[[paste0("binary_excess_", 1)]] == 1), ]
      Dat$index <- Dat[[paste0("binary_deficit_", 1)]]
    }
    if(region!="region_est3"){
      fe_part <- paste0("year^", region,"+region_est3") 
    } else {
      fe_part <- paste0(region, "+year")  
    }
    
    model0 <- as.formula(
      paste0(dep_vars[i], " ~ index + ",
             paste0(controls, collapse = "+"), " | ", fe_part)
    )
    
    model1 <- as.formula(
      paste0(dep_vars[i], " ~ i(sector, index) + ",
             paste0(controls, collapse = "+"), " | ", fe_part)
    )
    res0<-summary(feols(model0,Dat,vcov = "clust"))
    res1<-summary(feols(model1,Dat,vcov = "clust"))
    CIs0<-do.call(cbind,lapply(c(0.9,0.95),function(i){
      confint(res0, level=i)[1,]
    }))
    CIs0 <- cbind(coef = res0$coefficients[1], CIs0, nobs = res0$nobs)
    CIs<-do.call(cbind,lapply(c(0.9,0.95),function(i){
      confint(res1, level=i)[1:3,]
    }))
    CIs <- cbind(coef = res1$coefficients[1:3], CIs, nobs = res1$nobs)
    res<-rbind(CIs0,CIs)
    labs_graph<-rownames(res)
    labs_graph<-ifelse(nchar(labs_graph)>5,
                       substring(labs_graph,9,nchar(labs_graph)-6),"All")
    dat_graph<-data.frame(res,clust=labs_graph)
    colnames(dat_graph)<-c("coef","lower_10","upper_10","lower_5",
                           "upper_5","nobs","clust")
    dat_graph$clust<-factor(dat_graph$clust,levels=
                              c("All","Primary",
                                "Secondary","Tertiary"))
    dat_graph$ops<-ops[k]
    dat_graph$region<-region_levels[j]
    dat_graph$region<-ifelse(dat_graph$region=="region_est3","Baseline",
                             dat_graph$region)
    dat_graph$region<-ifelse(dat_graph$region=="region_est1","Province TT",
                             dat_graph$region)
    return(dat_graph)})
  dat_graph<-do.call(rbind,Graph)
  graph<-ggplot(data = dat_graph, aes(x =ops, y = coef, fill = region)) + 
    facet_wrap(~clust, strip.position = "bottom", scales = "free_x",ncol=4)+
    scale_fill_manual(values = c('black', 'grey'),name="")+
    geom_errorbar(aes(ymin = lower_10 , ymax =  upper_10,color='90 % C.I'),
                  position=position_dodge(width=0.8),width=0.4,size=0.7)+
    geom_errorbar(aes(ymin = lower_5 , ymax =  upper_5,color='95 % C.I'),
                  position=position_dodge(width=0.8),width=0.5,size=0.7)+ 
    geom_point(position=position_dodge(width=0.8),shape=22,size=8) +
    theme_bw()+
    xlab("")+ggtitle("")+
    ylab("Effect")+
    geom_hline(yintercept = 0,linetype='dotted', col = 'black',size=0.8)+
    theme(plot.title = element_text(hjust = 0.5))+
    scale_color_manual(name='',
                       values=c('95 % C.I'='black','90 % C.I'='grey'))+
    theme(plot.title = element_text(hjust = 0.5,size = 45),
          axis.title.x = element_text(size = 30),
          axis.title.y = element_text(size = 40),
          axis.text.y = element_text(face="bold", 
                                     size=35
          ),legend.text = element_text(size=37),
          legend.title = element_text(""),
          axis.text.x = element_text(face="bold", size=35),
          legend.key.height = unit(2, "cm"),
          strip.text.x = element_text(size = 45),
          strip.placement = "outside")
  return(list(graph = graph, data = dat_graph)) })
all_data_ur <- list()  
for (i in seq_along(dep_vars)) {
  
  # Extract graph and data
  g <- Rob_tt_dat[[i]]$graph
  dat <- Rob_tt_dat[[i]]$data
  
  # Build filename with dep var name + quantile index
  fname <- paste0("rob_check",dep_vars[i], ".pdf")
  
  # Save graph without displaying
  
  ggsave(fname, plot = g, width = 25, height = 11)
  
  
  # Store dat_graph with identifiers
  dat$dep_var <- dep_vars[i]
  all_data_ur[[dep_vars[i]]] <- dat
}
all_df <- do.call(rbind, all_data_ur)
###################
cluster_levels <- c("region_est3", "region_est2", "region_est1") # Levels to cluster by

# Create a grid of all combinations: operation (Flood/Drought) and cluster level
Loop_arg <- expand.grid(op = ops, cluster_level = cluster_levels, stringsAsFactors = FALSE)

# The main loop
Rob_tt_dat <- lapply(1:length(dep_vars), function(i){
  
  Graph <- lapply(1:nrow(Loop_arg), function(s){
    
    # Get the parameters for this iteration
    op <- Loop_arg[s, "op"]
    cluster_var <- Loop_arg[s, "cluster_level"]
    
    # Subset the data for Flood or Drought
    if(op == "Flood"){
      Dat <- Data[-which(Data[[paste0("binary_deficit_", 1)]] == 1), ]
      Dat$index <- Dat[[paste0("binary_excess_", 1)]] 
    } else {
      Dat <- Data[-which(Data[[paste0("binary_excess_", 1)]] == 1), ]
      Dat$index <- Dat[[paste0("binary_deficit_", 1)]]
    }
    
    # Fixed effects are ALWAYS region_est3 + year
    fe_part <- "region_est3 + year"
    
    # Construct the model formulas
    model0 <- as.formula(
      paste0(dep_vars[i], " ~ index + ",
             paste0(controls, collapse = "+"), " | ", fe_part)
    )
    
    model1 <- as.formula(
      paste0(dep_vars[i], " ~ i(sector, index) + ",
             paste0(controls, collapse = "+"), " | ", fe_part)
    )
    
    # Estimate models with clustering at the specified level
    res0 <- feols(model0, Dat, vcov = as.formula(paste0("~", cluster_var)))
    res1 <- feols(model1, Dat, vcov = as.formula(paste0("~", cluster_var)))
    
    # Compute ONLY the 0.95 confidence intervals for the first model (aggregate 'All')
    CIs0 <- confint(res0, level = 0.95)[1, , drop = FALSE] # Get 95% CI for 'index'
    CIs0 <- cbind(coef = res0$coefficients[1], CIs0, nobs = res0$nobs)
    
    # Compute ONLY the 0.95 confidence intervals for the sectoral model
    CIs <- confint(res1, level = 0.95)[1:3, ] # Get 95% CI for sectoral coefficients
    CIs <- cbind(coef = res1$coefficients[1:3], CIs, nobs = res1$nobs)
    
    # Combine the results
    res <- rbind(CIs0, CIs)
    labs_graph <- rownames(res)
    labs_graph <- ifelse(nchar(labs_graph) > 5,
                         substring(labs_graph, 9, nchar(labs_graph) - 6), "All")
    dat_graph <- data.frame(res, clust = labs_graph)
    colnames(dat_graph) <- c("coef", "lower_5", "upper_5", "nobs", "clust")
    dat_graph$clust <- factor(dat_graph$clust, levels = c("All", "Primary", "Secondary", "Tertiary"))
    dat_graph$op <- op
    dat_graph$cluster_level <- cluster_var # Store which level we clustered on
    dat_graph$cluster_level<-ifelse(dat_graph$cluster_level=="region_est3",
                                    "Parish",dat_graph$cluster_level)
    dat_graph$cluster_level<-ifelse(dat_graph$cluster_level=="region_est2",
                                    "Canton",dat_graph$cluster_level)
    dat_graph$cluster_level<-ifelse(dat_graph$cluster_level=="region_est1",
                                    "Province",dat_graph$cluster_level)
    return(dat_graph)
  })
  # Combine results for all ops/cluster levels for this dependent variable
  dat_graph <- do.call(rbind, Graph)
  
  # Create the plot
  # Create the plot - CORRECTED VERSION
  graph <- ggplot(data = dat_graph, aes(x = op, y = coef)) +
    facet_wrap(~clust, strip.position = "bottom", scales = "free_x", ncol = 4) +
    # REMOVE position_dodge to make error bars overlap
    # Map color to cluster_level for the error bars
    geom_errorbar(aes(ymin = lower_5, ymax = upper_5, color = cluster_level),
                  width = 0.4, size = 0.7) + # Position dodge removed
    geom_point(size = 3) + # Position dodge removed from here as well
    theme_bw() +
    xlab("") +
    ylab("Effect") +
    geom_hline(yintercept = 0, linetype = 'dotted', col = 'black', size = 0.8) +
    # Specify a color scale for the three cluster levels
    scale_color_manual(name = 'Cluster Level',
                       values = c('Parish' = '#E41A1C', # Red
                                  'Canton' = '#377EB8', # Blue
                                  'Province' = '#4DAF4A')) + # Green
    theme(plot.title = element_text(hjust = 0.5),
          axis.title.x = element_text(size = 14),
          axis.title.y = element_text(size = 14),
          axis.text.y = element_text(size = 12),
          legend.text = element_text(size = 12),
          axis.text.x = element_text(size = 12),
          strip.text.x = element_text(size = 12),
          strip.placement = "outside")
  
  return(list(graph = graph, data = dat_graph))
})

# Save the graphs and combine the data
all_data_ur <- list()  
for (i in seq_along(dep_vars)) {
  
  # Extract graph and data
  g <- Rob_tt_dat[[i]]$graph
  dat <- Rob_tt_dat[[i]]$data
  
  # Add a column to identify the dependent variable
  dat$dep_var <- dep_vars[i]
  
  # Build filename with dep var name
  fname <- paste0("robustness_cluster_", dep_vars[i], ".pdf")
  
  # Save graph
  ggsave(fname, plot = g, width = 14, height = 8)
  
  # Store data
  all_data_ur[[i]] <- dat
}
# Combine all data into one dataframe
all_df <- do.call(rbind, all_data_ur)


# Panel Analysis after 2021
Data<-Data%>%
  dplyr::mutate(panelm_pad = str_pad(panelm, width = 3, pad="0"),
    id_ind = paste0(panelm_pad, vivienda, hogar, p01)) # Create the individual identifiers

Data_panel = Data[which(Data$year>2020),] # Select data 2021-2024

Graph_panel <- lapply(1:3, function(k){   # loop over quantile sets
  lapply(1:length(dep_vars), function(i){
    
    Both <- lapply(1:length(ops), function(j){
      if (ops[j] == "Excess") {
        Dat <- Data_panel[-which(Data_panel[[paste0("binary_deficit_", k)]] == 1), ]
        Dat$index <- Dat[[paste0("binary_excess_", k)]]
      } else {
        Dat <- Data_panel[-which(Data_panel[[paste0("binary_excess_", k)]] == 1), ]
        Dat$index <- Dat[[paste0("binary_deficit_", k)]]
      }
      
      model0 <- formula(paste0(dep_vars[i], "~ index +", 
                               paste0(controls, collapse = "+"),
                               "|id_ind + year"))
      model1 <- formula(paste0(dep_vars[i], "~i(sector, index)+", 
                               paste0(controls, collapse = "+"),
                               "|id_ind + year"))
      
      res0 <- summary(feols(model0, Dat, vcov = "clust"))
      res1 <- summary(feols(model1, Dat, vcov = "clust"))
      
      # Add nobs to res0 results
      CIs0 <- do.call(cbind, lapply(c(0.9,0.95), function(lvl){
        confint(res0, level = lvl)[1, ]
      }))
      CIs0 <- cbind(coef = res0$coefficients[1], CIs0, nobs = res0$nobs)
      
      # Add nobs to res1 results
      CIs <- do.call(cbind, lapply(c(0.9,0.95), function(lvl){
        confint(res1, level = lvl)[1:3, ]
      }))
      CIs <- cbind(coef = res1$coefficients[1:3], CIs, nobs = res1$nobs)
      
      res <- rbind(CIs0, CIs)
      labs_graph <- rownames(res)
      labs_graph <- ifelse(nchar(labs_graph) > 5,
                           substring(labs_graph, 9, nchar(labs_graph) - 6),
                           "All")
      
      dat_graph <- data.frame(res, clust = labs_graph)
      colnames(dat_graph)[1:6] <- c("coef","lower_10","upper_10","lower_5","upper_5","nobs")
      dat_graph$clust <- factor(dat_graph$clust, 
                                levels = c("All","Primary","Secondary","Tertiary"))
      dat_graph$ops <- ops[j]
      return(dat_graph)
    })
    
    dat_graph <- rbind(Both[[1]], Both[[2]])
    
    graph <- ggplot(data = dat_graph, aes(x = ops, y = coef)) + 
      facet_wrap(~clust, strip.position = "bottom", scales = "free_x", ncol = 4) +
      geom_errorbar(aes(ymin = lower_10 , ymax =  upper_10, color = '90 % C.I'),
                    position = position_dodge(width = 1), width = 0.4, size = 0.7) +
      geom_errorbar(aes(ymin = lower_5 , ymax =  upper_5, color = '95 % C.I'),
                    position = position_dodge(width = 1), width = 0.5, size = 0.7) +
      geom_point(position = position_dodge(width = 0.8), shape = 22, size = 12, aes(fill = ops)) +
      scale_fill_manual(values = c('black', 'grey'), name = "") +
      theme_bw() +
      xlab("") + ggtitle("") +
      ylab("Effect") +
      geom_hline(yintercept = 0, linetype = 'dotted', col = 'black', size = 0.8) +
      theme(plot.title = element_text(hjust = 0.5)) +
      scale_color_manual(name = '',
                         values = c('95 % C.I' = 'black','90 % C.I' = 'grey')) +
      theme(plot.title = element_text(hjust = 0.5, size = 37),
            axis.title.x = element_text(size = 30),
            axis.title.y = element_text(size = 40),
            axis.text.y = element_text(face = "bold", size = 35),
            legend.text = element_text(size = 37),
            legend.title = element_text(""),
            axis.text.x = element_text(face = "bold", size = 35),
            legend.key.height = unit(2, "cm"),
            strip.text.x = element_text(size = 45),
            strip.placement = "outside")
    return(list(graph = graph, data = dat_graph))
  })
})
all_data_panel <- list()  # to store all dat_graph tables

## Figures A7, A8, and A9
for (k in 1:3) {
  for (i in seq_along(dep_vars)) {
    setwd("C:/Users/q33044/Desktop/Research/Revision_Ecuador_WD/Figures") # Set your own working directory
    # Extract graph and data
    g <- Graph_panel[[k]][[i]]$graph
    dat <- Graph_panel[[k]][[i]]$data
    
    # Build filename with dep var name + quantile index
    fname <- paste0(dep_vars[i], "panel_qset", k, ".pdf")
    
    # Save graph without displaying
    if(k==1){
      ggsave(fname, plot = g, width = 25, height = 11)
    }
    
    # Store dat_graph with identifiers
    dat$dep_var <- dep_vars[i]
    dat$qset <- k
    all_data_panel[[paste0(dep_vars[i], "panel_qset", k)]] <- dat
  }
}


