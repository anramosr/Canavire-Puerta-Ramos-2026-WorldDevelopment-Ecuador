rm(list=ls())
library(data.table)
library(haven)
library(dplyr)
library(fixest)
library(parallel)
library(ggplot2)
library(ggpubr)
library(gt)
library(xtable)

setwd("C:/Users/q33044/Desktop/Research/Revision_Ecuador_WD/") # Set your own working directory
Data<-fread("Data/Data_estimation_rev.csv")
Data$categ_lab<-Data$formal
Data$sector1d<-Data$ecSec
group1<-c(2,6) #Agriculture and Mining
group2<-c(4,5) # Construction and Manufacturing
group3<-c(1,3) # Services and Commerce
Data$sector<-Data$sector1d
Data$sector<-ifelse(Data$sector%in% group1,'Primary',
                    Data$sector)
Data$sector<-ifelse(Data$sector %in% group2,'Secondary',
                    Data$sector)
Data$sector<-ifelse(Data$sector %in% group3,'Tertiary',Data$sector)
dep_vars<-c("ipcf","ila","poorEC")
names_dep<-c("Per Capita Household Income","Labor Income","Poverty Rate")
ops<-c("Excess","Deficit")
Data$ipcf<-log(Data$ipcf+1)
Data$ila<-log(Data$ila+1)
controls<-c("as.factor(estado_civil)","hombre","edad", "aedu", "temp_max", "temp_min")
Data$region_est3<-as.character(Data$region_est3)
Data$region_est3<-ifelse(nchar(Data$region_est3)==5,paste0("0",Data$region_est3),
                         Data$region_est3)
Data$region_est2<-substr(Data$region_est3,1,4)
Data$region_est1<-substr(Data$region_est3,1,2)
Graph <- lapply(1:3, function(k){   # loop over quantile sets
  lapply(1:length(dep_vars), function(i){
    
    Both <- lapply(1:length(ops), function(j){
      if (ops[j] == "Excess") {
        Dat <- Data[-which(Data[[paste0("binary_deficit_", k)]] == 1), ]
        Dat$index <- Dat[[paste0("binary_excess_", k)]]
      } else {
        Dat <- Data[-which(Data[[paste0("binary_excess_", k)]] == 1), ]
        Dat$index <- Dat[[paste0("binary_deficit_", k)]]
      }
      
      model0 <- formula(paste0(dep_vars[i], "~ index +", 
                               paste0(controls, collapse = "+"),
                               "|region_est3 + year"))
      model1 <- formula(paste0(dep_vars[i], "~i(sector, index)+", 
                               paste0(controls, collapse = "+"),
                               "|region_est3 + year"))
      
      res0 <- summary(feols(model0, Dat, vcov = "clust"))
      res1 <- summary(feols(model1, Dat, vcov = "clust"))
      
      # Add nobs to res0 results
      CIs0 <- do.call(cbind, lapply(c(0.9,0.95), function(lvl){
        confint(res0, level = lvl)[1, ]
      }))
      CIs0 <- cbind(coef = res0$coefficients[1], CIs0, nobs = res0$nobs)
      
      # Add nobs to res1 results
      CIs <- do.call(cbind, lapply(c(0.9,0.95), function(lvl){
        confint(res1, level = lvl)[1:3, ]
      }))
      CIs <- cbind(coef = res1$coefficients[1:3], CIs, nobs = res1$nobs)
      
      res <- rbind(CIs0, CIs)
      labs_graph <- rownames(res)
      labs_graph <- ifelse(nchar(labs_graph) > 5,
                           substring(labs_graph, 9, nchar(labs_graph) - 6),
                           "All")
      
      dat_graph <- data.frame(res, clust = labs_graph)
      colnames(dat_graph)[1:6] <- c("coef","lower_10","upper_10","lower_5","upper_5","nobs")
      dat_graph$clust <- factor(dat_graph$clust, 
                                levels = c("All","Primary","Secondary","Tertiary"))
      dat_graph$ops <- ops[j]
      return(dat_graph)
    })
    
    dat_graph <- rbind(Both[[1]], Both[[2]])
    
    graph <- ggplot(data = dat_graph, aes(x = ops, y = coef)) + 
      facet_wrap(~clust, strip.position = "bottom", scales = "free_x", ncol = 4) +
      geom_errorbar(aes(ymin = lower_10 , ymax =  upper_10, color = '90 % C.I'),
                    position = position_dodge(width = 1), width = 0.4, size = 0.7) +
      geom_errorbar(aes(ymin = lower_5 , ymax =  upper_5, color = '95 % C.I'),
                    position = position_dodge(width = 1), width = 0.5, size = 0.7) +
      geom_point(position = position_dodge(width = 0.8), shape = 22, size = 12, aes(fill = ops)) +
      scale_fill_manual(values = c('black', 'grey'), name = "") +
      theme_bw() +
      xlab("") + ggtitle("") +
      ylab("Effect") +
      geom_hline(yintercept = 0, linetype = 'dotted', col = 'black', size = 0.8) +
      theme(plot.title = element_text(hjust = 0.5)) +
      scale_color_manual(name = '',
                         values = c('95 % C.I' = 'black','90 % C.I' = 'grey')) +
      theme(plot.title = element_text(hjust = 0.5, size = 37),
            axis.title.x = element_text(size = 30),
            axis.title.y = element_text(size = 40),
            axis.text.y = element_text(face = "bold", size = 35),
            legend.text = element_text(size = 37),
            legend.title = element_text(""),
            axis.text.x = element_text(face = "bold", size = 35),
            legend.key.height = unit(2, "cm"),
            strip.text.x = element_text(size = 45),
            strip.placement = "outside")
      return(list(graph = graph, data = dat_graph))
  })
})
all_data <- list()  # to store all dat_graph tables
## Figures 2,6,10 
for (k in 1:3) {
  for (i in seq_along(dep_vars)) {
    
    # Extract graph and data
    g <- Graph[[k]][[i]]$graph
    dat <- Graph[[k]][[i]]$data
    
    # Build filename with dep var name + quantile index
    fname <- paste0(dep_vars[i], "_qset", k, ".pdf")
    
    # Save graph without displaying
    if(k==1){
      ggsave(fname, plot = g, width = 25, height = 11)
    }
    
    # Store dat_graph with identifiers
    dat$dep_var <- dep_vars[i]
    dat$qset <- k
    all_data[[paste0(dep_vars[i], "_qset", k)]] <- dat
  }
} 
all_data_df <- do.call(rbind, all_data)
all_data_df <- all_data_df %>%
  mutate(
    qset = case_when(
      qset == 1 ~ "25",
      qset == 2 ~ "10",
      qset == 3 ~ "40",
      TRUE ~ as.character(qset)
    ),
    est_ci = paste0(sprintf("%.3f", coef),
                    " (", sprintf("%.3f", lower_5),
                    ", ", sprintf("%.3f", upper_5), ")")
  )
all_data_df<-select(all_data_df,-all_of(c("coef",
             "lower_10", "upper_10", "lower_5",  "upper_5")))%>%
  arrange(qset,ops)
shocks<-c("Excess","Deficit")
qs<-c(10,25,40)
Tabs<-lapply(1:length(dep_vars), function(i){
  loc_dat<-filter(all_data_df,dep_var==dep_vars[i])
  res_loc_1<-do.call(rbind,lapply(1:length(shocks), function(j){
    loc_dat_1<-filter(loc_dat,ops==shocks[j])
    res_loc<-do.call(rbind,lapply(1:length(qs), function(k){
      loc_dat_2<-filter(loc_dat_1,qset==qs[k]) 
      all<-loc_dat_2[loc_dat_2$clust == "All", c("est_ci", "nobs")]
      rest<-c(loc_dat_2[loc_dat_2$clust=="Primary","est_ci"],
              loc_dat_2[loc_dat_2$clust=="Secondary","est_ci"],
              loc_dat_2[loc_dat_2$clust=="Tertiary","est_ci"],
              loc_dat_2[loc_dat_2$clust=="Primary","nobs"])
      res<-do.call(cbind,c(qs[k],all,rest))
    }))
  }))
})
## Table A1 
print(xtable(Tabs[[3]]), include.rownames = FALSE)
urb<-c("Rural","Urban")
Loop_arg<-expand.grid(c(2,1),c(2,1))
Fig3_dat<-lapply(1:3, function(m){ lapply(1:length(dep_vars), function(i){
  Graph<-lapply(1:dim(Loop_arg)[1], function(s){
    j<-Loop_arg[s,1]
    k<-Loop_arg[s,2]
    if(j==1){ Dat<-filter(Data,urbano!=1) 
    } else{  Dat<-filter(Data,urbano==1)}
    if(ops[k]=="Flood"){
      Dat <- Dat[-which(Dat[[paste0("binary_deficit_", m)]] == 1), ]
      Dat$index <- Dat[[paste0("binary_excess_", m)]] 
    } else{
      Dat <- Dat[-which(Dat[[paste0("binary_excess_", m)]] == 1), ]
      Dat$index <- Dat[[paste0("binary_deficit_", m)]]
    }
    model0<-formula(paste0(dep_vars[i],"~index+",paste0(controls,collapse = "+"),
                           "|region_est3+year"))
    model1<-formula(paste0(dep_vars[i],"~i(sector,index)+",
                           paste0(controls,collapse = "+"),
                           "|region_est3+year"))
    res0<-summary(feols(model0,Dat,vcov = "clust"))
    res1<-summary(feols(model1,Dat,vcov = "clust"))
    CIs0<-do.call(cbind,lapply(c(0.9,0.95),function(i){
      confint(res0, level=i)[1,]
    }))
    CIs0 <- cbind(coef = res0$coefficients[1], CIs0, nobs = res0$nobs)
    CIs<-do.call(cbind,lapply(c(0.9,0.95),function(i){
      confint(res1, level=i)[1:3,]
    }))
    CIs <- cbind(coef = res1$coefficients[1:3], CIs, nobs = res1$nobs)
    res<-rbind(CIs0,CIs)
    labs_graph<-rownames(res)
    labs_graph<-ifelse(nchar(labs_graph)>5,
                       substring(labs_graph,9,nchar(labs_graph)-6),"All")
    dat_graph<-data.frame(res,clust=labs_graph)
    colnames(dat_graph)<-c("coef","lower_10","upper_10","lower_5",
                           "upper_5","nobs","clust")
    dat_graph$clust<-factor(dat_graph$clust,levels=
                              c("All","Primary",
                                "Secondary","Tertiary"))
    dat_graph$ops<-ops[k]
    dat_graph$urban<-urb[j]
    return(dat_graph)})
  dat_graph<-do.call(rbind,Graph)
  graph<-ggplot(data = dat_graph, aes(x =ops, y = coef, fill = urban)) + 
    facet_wrap(~clust, strip.position = "bottom", scales = "free_x",ncol=4)+
    scale_fill_manual(values=c('black', 'grey'),name="")+
    geom_errorbar(aes(ymin = lower_10 , ymax =  upper_10,color='90 % C.I'),
                  position=position_dodge(width=0.8),width=0.4,size=0.7)+
    geom_errorbar(aes(ymin = lower_5 , ymax =  upper_5,color='95 % C.I'),
                  position=position_dodge(width=0.8),width=0.5,size=0.7)+ 
    geom_point(position=position_dodge(width=0.8),shape=22,size=8) +
    theme_bw()+
    xlab("")+ggtitle("")+
    ylab("Effect")+
    geom_hline(yintercept = 0,linetype='dotted', col = 'black',size=0.8)+
    theme(plot.title = element_text(hjust = 0.5))+
    scale_color_manual(name='',
                       values=c('95 % C.I'='black','90 % C.I'='grey'))+
    theme(plot.title = element_text(hjust = 0.5,size = 45),
          axis.title.x = element_text(size = 30),
          axis.title.y = element_text(size = 40),
          axis.text.y = element_text(face="bold", 
                                     size=35
          ),legend.text = element_text(size=37),
          legend.title = element_text(""),
          axis.text.x = element_text(face="bold", size=35),
          legend.key.height = unit(2, "cm"),
          strip.text.x = element_text(size = 45),
          strip.placement = "outside")
  return(list(graph = graph, data = dat_graph)) })})
all_data_ur <- list()  
# Figure 3
for (k in 1:3) {
  for (i in seq_along(dep_vars)) {
    
    # Extract graph and data
    g <- Fig3_dat[[k]][[i]]$graph
    dat <- Fig3_dat[[k]][[i]]$data
    
    # Build filename with dep var name + quantile index
    fname <- paste0("urb_rur",dep_vars[i], "_qset", k, ".pdf")
    
    # Save graph without displaying
    if(k==1 & i==3){
      ggsave(fname, plot = g, width = 25, height = 11)
    }
    
    # Store dat_graph with identifiers
    dat$dep_var <- dep_vars[i]
    dat$qset <- k
    all_data_ur[[paste0(dep_vars[i], "_qset", k)]] <- dat
  }
}
all_data_ur_df <- do.call(rbind, all_data_ur)
all_data_ur_df <- all_data_ur_df %>%
  mutate(
    qset = case_when(
      qset == 1 ~ "25",
      qset == 2 ~ "10",
      qset == 3 ~ "40",
      TRUE ~ as.character(qset)
    ),
    est_ci = paste0(sprintf("%.3f", coef),
                    " (", sprintf("%.3f", lower_5),
                    ", ", sprintf("%.3f", upper_5), ")"))
all_ur<-filter(all_data_ur_df,dep_var=="poorEC")
Tab_urb_rur<-do.call(rbind,lapply(1:length(shocks), function(i){
  loc_dat<-filter(all_ur,ops==shocks[i])
  res_loc_1<-do.call(rbind,lapply(1:length(urb), function(j){
    loc_dat_1<-filter(loc_dat,urban==urb[j])
    res_loc<-do.call(rbind,lapply(1:length(qs), function(k){
      loc_dat_2<-filter(loc_dat_1,qset==qs[k]) 
      all<-loc_dat_2[loc_dat_2$clust == "All", c("est_ci", "nobs")]
      rest<-c(loc_dat_2[loc_dat_2$clust=="Primary","est_ci"],
              loc_dat_2[loc_dat_2$clust=="Secondary","est_ci"],
              loc_dat_2[loc_dat_2$clust=="Tertiary","est_ci"],
              loc_dat_2[loc_dat_2$clust=="Primary","nobs"])
      res<-do.call(cbind,c(qs[k],all,rest))
    }))
  }))
}))
## Tab A2
print(xtable(Tab_urb_rur), include.rownames = FALSE)
formal<-c("Informal","Formal")
Loop_arg<-expand.grid(c(1,2),c(1,2))
Graph4<-lapply(1:length(dep_vars), function(i){
  lapply(1:2, function(m){
    if(m==1){
      Dat <- Data[-which(Data[[paste0("binary_deficit_", 1)]] == 1), ]
      Dat$index <- Dat[[paste0("binary_excess_", 1)]] 
    } else{
      Dat <- Data[-which(Data[[paste0("binary_excess_", 1)]] == 1), ]
      Dat$index <- Dat[[paste0("binary_deficit_", 1)]]
    }
    Graph<-lapply(1:dim(Loop_arg)[1], function(s){
      j<-Loop_arg[s,1]
      k<-Loop_arg[s,2]
      if(k==1){
        Dat<-filter(Dat,urbano!=1) # 1 = Rural
      } else{
        Dat<-filter(Dat,urbano==1)
      }
      if(j==1){ Dat<-filter(Dat,categ_lab==1) # 1 = Informal
      } else { Dat<-filter(Dat,categ_lab!=1)}
      model0<-formula(paste0(dep_vars[i],"~index+",paste0(controls,collapse = "+"),
                             "|region_est3+year"))
      model1<-formula(paste0(dep_vars[i],"~i(sector,index)+",
                             paste0(controls,collapse = "+"),
                             "|region_est3+year"))
      res0<-summary(feols(model0,Dat,vcov = "clust"))
      res1<-summary(feols(model1,Dat,vcov = "clust"))
      CIs0<-do.call(cbind,lapply(c(0.9,0.95),function(i){
        confint(res0, level=i)[1,]
      }))
      CIs0 <- cbind(coef = res0$coefficients[1], CIs0, nobs = res0$nobs)
      CIs<-do.call(cbind,lapply(c(0.9,0.95),function(i){
        confint(res1, level=i)[1:3,]
      }))
      CIs <- cbind(coef = res1$coefficients[1:3], CIs, nobs = res1$nobs)
      res<-rbind(CIs0,CIs)
      labs_graph<-rownames(res)
      labs_graph<-ifelse(nchar(labs_graph)>5,
                         substring(labs_graph,9,nchar(labs_graph)-6),"All")
      dat_graph<-data.frame(res,clust=labs_graph)
      colnames(dat_graph)<-c("coef","lower_10","upper_10","lower_5",
                             "upper_5","nobs","clust")
      dat_graph$clust<-factor(dat_graph$clust,levels=
                                c("All","Primary",
                                  "Secondary","Tertiary"))
      dat_graph$ops<-ops[m]
      dat_graph$urban<-urb[k]
      dat_graph$formal<-formal[j]
      return(dat_graph)})
    dat_graph<-do.call(rbind,Graph)
    graph<-ggplot(data = dat_graph, aes(x = urban, y = coef, fill = formal)) + 
      facet_wrap(~clust, strip.position = "bottom", scales = "free_x",ncol=4)+
      scale_fill_manual(values=c('blue', 'red'),name="")+
      geom_errorbar(aes(ymin = lower_10 , ymax =  upper_10,color='90 % C.I'),
                    position=position_dodge(width=0.8),width=0.4,size=1.4)+
      geom_errorbar(aes(ymin = lower_5 , ymax =  upper_5,color='95 % C.I'),
                    position=position_dodge(width=0.8),width=0.5,size=1.4)+ 
      geom_point(position=position_dodge(width=0.8),shape=22,size=20) +
      theme_bw()+
      xlab("")+ggtitle(ifelse(m==1,"Flood","Drought"))+
      ylab("Effect")+
      geom_hline(yintercept = 0,linetype='dotted', col = 'black',size=0.8)+
      theme(plot.title = element_text(hjust = 0.5))+
      scale_color_manual(name='',
                         values=c('95 % C.I'='black','90 % C.I'='grey'))+
      theme(plot.title = element_text(hjust = 0.5,size = 45),
            axis.title.x = element_text(size = 30),
            axis.title.y = element_text(size = 40),
            axis.text.y = element_text(face="bold", 
                                       size=35
            ),legend.text = element_text(size=37),
            legend.title = element_text(""),
            axis.text.x = element_text(face="bold", size=35),
            legend.key.height = unit(2, "cm"),
            strip.text.x = element_text(size = 45),
            strip.placement = "outside")
    return(list(graph = graph, data = dat_graph))})})
Graph4[[3]][[1]]$graph
ggsave("poverty_flood.pdf", width = 40, height = 18)
Graph4[[3]][[2]]$graph
ggsave("poverty_drought.pdf", width = 40, height = 18)
Graph4[[2]][[1]]$graph
ggsave("lab_income_flood.pdf", width = 40, height = 18)
Graph4[[2]][[2]]$graph
ggsave("lab_income_drought.pdf", width = 40, height = 18)
Graph4[[1]][[1]]$graph
ggsave("hh_income_flood.pdf", width = 40, height = 18)
Graph4[[1]][[2]]$graph
ggsave("hh_income_drought.pdf", width = 40, height = 18)
Tables_formal <-lapply(1:3, function(i) {
  do.call(rbind,lapply(1:2, function(k) {
    do.call(rbind, lapply(Graph4[[i]][[k]], function(x) x$data))
  }))
})
Tabs_formal<-lapply(1:3, function(mm){
  pov_formal<-Tables_formal[[mm]]
  pov_formal <- pov_formal %>%
    mutate(est_ci = paste0(sprintf("%.3f", coef),
                           " (", sprintf("%.3f", lower_5),
                           ", ", sprintf("%.3f", upper_5), ")"))
  formals<-formal
  Tab_formal<-do.call(rbind,lapply(1:length(shocks), function(i){
    loc_dat<-filter(pov_formal,ops==shocks[i])
    res_loc_1<-do.call(rbind,lapply(1:length(urb), function(j){
      loc_dat_1<-filter(loc_dat,urban==urb[j])
      res_loc<-do.call(rbind,lapply(1:length(formal), function(k){
        loc_dat_2<-filter(loc_dat_1,formal==formals[k]) 
        all<-loc_dat_2[loc_dat_2$clust == "All", c("est_ci", "nobs")]
        rest<-c(loc_dat_2[loc_dat_2$clust=="Primary","est_ci"],
                loc_dat_2[loc_dat_2$clust=="Secondary","est_ci"],
                loc_dat_2[loc_dat_2$clust=="Tertiary","est_ci"],
                loc_dat_2[loc_dat_2$clust=="Primary","nobs"])
        res<-do.call(cbind,c(formals[k],all,rest))
      }))
    }))
  }))
})
## Tab A3
print(xtable(Tabs_formal[[3]]), include.rownames = FALSE)

employed<-c("Self-employed","Not Self-employed")
Loop_arg<-expand.grid(c(1,2),c(1,2))
Graph5<-lapply(1:length(dep_vars), function(i){
  lapply(1:2, function(m){
    if(m==1){
      Dat <- Data[-which(Data[[paste0("binary_deficit_", 1)]] == 1), ]
      Dat$index <- Dat[[paste0("binary_excess_", 1)]] 
    } else{
      Dat <- Data[-which(Data[[paste0("binary_excess_", 1)]] == 1), ]
      Dat$index <- Dat[[paste0("binary_deficit_", 1)]]
    }
    Graph<-lapply(1:dim(Loop_arg)[1], function(s){
      j<-Loop_arg[s,1]
      k<-Loop_arg[s,2]
      if(k==1){
        Dat<-filter(Dat,firmS_3==1) # 1 = Self-Employed
      } else{
        Dat<-filter(Dat,firmS_3!=1)
      }
      if(j==1){ Dat<-filter(Dat,categ_lab==1) 
      } else { Dat<-filter(Dat,categ_lab!=1)}
      model0<-formula(paste0(dep_vars[i],"~index+",paste0(controls,collapse = "+"),
                             "|region_est3+year"))
      model1<-formula(paste0(dep_vars[i],"~i(sector,index)+",
                             paste0(controls,collapse = "+"),
                             "|region_est3+year"))
      res0<-summary(feols(model0,Dat,vcov = "clust"))
      res1<-summary(feols(model1,Dat,vcov = "clust"))
      CIs0<-do.call(cbind,lapply(c(0.9,0.95),function(i){
        confint(res0, level=i)[1,]
      }))
      CIs0 <- cbind(coef = res0$coefficients[1], CIs0, nobs = res0$nobs)
      CIs<-do.call(cbind,lapply(c(0.9,0.95),function(i){
        confint(res1, level=i)[1:3,]
      }))
      CIs <- cbind(coef = res1$coefficients[1:3], CIs, nobs = res1$nobs)
      res<-rbind(CIs0,CIs)
      labs_graph<-rownames(res)
      labs_graph<-ifelse(nchar(labs_graph)>5,
                         substring(labs_graph,9,nchar(labs_graph)-6),"All")
      dat_graph<-data.frame(res,clust=labs_graph)
      colnames(dat_graph)<-c("coef","lower_10","upper_10","lower_5",
                             "upper_5","nobs","clust")
      dat_graph$clust<-factor(dat_graph$clust,levels=
                                c("All","Primary",
                                  "Secondary","Tertiary"))
      dat_graph$ops<-ops[m]
      dat_graph$urban<-urb[k]
      dat_graph$employed<-employed[j]
      return(dat_graph)})
    dat_graph<-do.call(rbind,Graph)
    graph<-ggplot(data = dat_graph, aes(x = urban, y = coef, fill = employed)) + 
      facet_wrap(~clust, strip.position = "bottom", scales = "free_x",ncol=4)+
      scale_fill_manual(values=c('blue', 'red'),name="")+
      geom_errorbar(aes(ymin = lower_10 , ymax =  upper_10,color='90 % C.I'),
                    position=position_dodge(width=0.8),width=0.4,size=1.4)+
      geom_errorbar(aes(ymin = lower_5 , ymax =  upper_5,color='95 % C.I'),
                    position=position_dodge(width=0.8),width=0.5,size=1.4)+ 
      geom_point(position=position_dodge(width=0.8),shape=22,size=20) +
      theme_bw()+
      xlab("")+ggtitle(ifelse(m==1,"Flood","Drought"))+
      ylab("Effect")+
      geom_hline(yintercept = 0,linetype='dotted', col = 'black',size=0.8)+
      theme(plot.title = element_text(hjust = 0.5))+
      scale_color_manual(name='',
                         values=c('95 % C.I'='black','90 % C.I'='grey'))+
      theme(plot.title = element_text(hjust = 0.5,size = 45),
            axis.title.x = element_text(size = 30),
            axis.title.y = element_text(size = 40),
            axis.text.y = element_text(face="bold", 
                                       size=35
            ),legend.text = element_text(size=37),
            legend.title = element_text(""),
            axis.text.x = element_text(face="bold", size=35),
            legend.key.height = unit(2, "cm"),
            strip.text.x = element_text(size = 45),
            strip.placement = "outside")
    return(list(graph = graph, data = dat_graph))})})
Graph5[[3]][[1]]$graph
ggsave("poverty_flood_self.pdf", width = 40, height = 18)
Graph5[[3]][[2]]$graph
ggsave("poverty_drought_self.pdf", width = 40, height = 18)
Graph5[[2]][[1]]$graph
ggsave("lab_income_flood_self.pdf", width = 40, height = 18)
Graph5[[2]][[2]]$graph
ggsave("lab_income_drought_self.pdf", width = 40, height = 18)
Graph5[[1]][[1]]$graph
ggsave("hh_income_flood_self.pdf", width = 40, height = 18)
Graph5[[1]][[2]]$graph
ggsave("hh_income_drought_self.pdf", width = 40, height = 18)
Tables_self <-lapply(1:3, function(i) {
  do.call(rbind,lapply(1:2, function(k) {
    do.call(rbind, lapply(Graph5[[i]][[k]], function(x) x$data))
  }))
})
Tabs_se<-lapply(1:3, function(mm){
  pov_self<-Tables_self[[mm]]
  pov_se <- pov_self %>%
    mutate(est_ci = paste0(sprintf("%.3f", coef),
                           " (", sprintf("%.3f", lower_5),
                           ", ", sprintf("%.3f", upper_5), ")"))
  employeds<-employed
  Tab_se<-do.call(rbind,lapply(1:length(shocks), function(i){
    loc_dat<-filter(pov_se,ops==shocks[i])
    res_loc_1<-do.call(rbind,lapply(1:length(urb), function(j){
      loc_dat_1<-filter(loc_dat,urban==urb[j])
      res_loc<-do.call(rbind,lapply(1:length(employed), function(k){
        loc_dat_2<-filter(loc_dat_1,employed==employeds[k]) 
        all<-loc_dat_2[loc_dat_2$clust == "All", c("est_ci", "nobs")]
        rest<-c(loc_dat_2[loc_dat_2$clust=="Primary","est_ci"],
                loc_dat_2[loc_dat_2$clust=="Secondary","est_ci"],
                loc_dat_2[loc_dat_2$clust=="Tertiary","est_ci"],
                loc_dat_2[loc_dat_2$clust=="Primary","nobs"])
        res<-do.call(cbind,c(employeds[k],all,rest))
      }))
    }))
  }))
})
## Tab A4
print(xtable(Tabs_se[[3]]), include.rownames = FALSE)
## Tab A5 
print(xtable(Tabs[[2]]), include.rownames = FALSE)
## Tab A6
print(xtable(Tabs_formal[[2]]), include.rownames = FALSE)
## Tab A7
print(xtable(Tabs_se[[2]]), include.rownames = FALSE)
## Tab A8 
print(xtable(Tabs[[1]]), include.rownames = FALSE)
## Tab A9
print(xtable(Tabs_formal[[1]]), include.rownames = FALSE)
## Tab A10
print(xtable(Tabs_se[[1]]), include.rownames = FALSE)
