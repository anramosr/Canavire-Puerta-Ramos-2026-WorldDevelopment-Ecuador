rm(list=ls())
library(data.table)
library(dplyr)
library(readxl)
library(labelled)
library(haven)
library(rgdal)
library(writexl)

setwd("C:/Users/q33044/Desktop/Research/Revision_Ecuador_WD/") # Set your own working directory
precip_ecuador2007_24 <- read_dta("Input/precip_ecuador2007_24.dta")
precip_ecuador2007_24 = precip_ecuador2007_24[which(precip_ecuador2007_24$year > 2006),] # Restrict to 2007-2024

# Precipitation index

mean_by_month <- aggregate(precipitacion ~ CODIGOP + month, data = precip_ecuador2007_24, FUN = mean)
sd_by_month   <- aggregate(precipitacion ~ CODIGOP + month, data = precip_ecuador2007_24, FUN = sd)
precip_index_data <- merge(precip_ecuador2007_24, mean_by_month, by = c("CODIGOP", "month"), suffixes = c("", "_mean"))
precip_index_data <- merge(precip_index_data, sd_by_month, by = c("CODIGOP", "month"), suffixes = c("", "_sd"))
precip_index_data$index = (precip_index_data$precipitacion - precip_index_data$precipitacion_mean)/precip_index_data$precipitacion_sd
plot(density(na.omit(precip_index_data$index)))

# Generate annual measures

max_index <- aggregate(index ~ CODIGOP + year, data = precip_index_data, FUN = max)
min_index <- aggregate(index ~ CODIGOP + year, data = precip_index_data, FUN = min)
annual_precipitation <- merge(max_index, min_index, by = c("CODIGOP", "year"), suffixes = c("_max", "_min"))

# Construct the binary shock

quantile_pairs <- list(c(0.75, 0.25), c(0.9, 0.1), c(0.4, 0.6))
for (i in seq_along(quantile_pairs)) {
  q <- quantile_pairs[[i]]
  
  alpha_0 <- quantile(na.omit(annual_precipitation$index_max), q[1])
  alpha_1 <- quantile(na.omit(annual_precipitation$index_min), q[2])
  
  # Variable names depend on iteration i
  annual_precipitation[[paste0("binary_excess_", i)]]  <- ifelse(annual_precipitation$index_max > alpha_0, 1, 0)
  annual_precipitation[[paste0("binary_deficit_", i)]] <- ifelse(annual_precipitation$index_min < alpha_1, 1, 0)
}

names(annual_precipitation)[1] = c("CC_3") # Change the name of the code variables for easy merging

# Save the data for later use
write_xlsx(annual_precipitation, "Data/annual_precipitation.xlsx")

# Generate plots for descriptive analysis

library(dplyr)
library(ggplot2)
library(scales)

q_prob <- 0.75
q_val <- quantile(annual_precipitation$index_max, probs = q_prob, na.rm = TRUE)

plot_max_index = ggplot(annual_precipitation, aes(x = index_max)) +
  geom_density(fill = "#3B82F6", alpha = 0.8, linewidth = 0.8) + # constant fill
  geom_vline(xintercept = q_val, linetype = "solid", linewidth = 1) +
  annotate("label",
           x = q_val, y = 0, vjust = -0.6, hjust = 0.5,
           label = paste0(percent(q_prob), " = ", round(q_val, 2)),
           label.size = 0, alpha = 0.9) +
  scale_x_continuous(labels = label_number(accuracy = 0.1)) +
  labs(
    x = "Values",
    y = "",
    title = "Distribution of the maximum precipitation index",
    subtitle = paste0("Vertical line: ", percent(q_prob), " quantile")
  ) +
  theme_minimal(base_size = 7) +
  theme(panel.grid.minor = element_blank(),
        plot.title.position = "plot")

ggsave("Figures/Figure1A.png", plot = plot_max_index)

q_prob <- 0.25
q_val <- quantile(annual_precipitation$index_min, probs = q_prob, na.rm = TRUE)

plot_min_index = ggplot(annual_precipitation, aes(x = index_min)) +
  geom_density(fill = "#FF0000", alpha = 0.8, linewidth = 0.8) + # constant fill
  geom_vline(xintercept = q_val, linetype = "solid", linewidth = 1) +
  annotate("label",
           x = q_val, y = 0, vjust = -0.6, hjust = 0.5,
           label = paste0(percent(q_prob), " = ", round(q_val, 2)),
           label.size = 0, alpha = 0.9) +
  scale_x_continuous(labels = label_number(accuracy = 0.1)) +
  labs(
    x = "Values",
    y = "",
    title = "Distribution of the minimum precipitation index",
    subtitle = paste0("Vertical line: ", percent(q_prob), " quantile")
  ) +
  theme_minimal(base_size = 7) +
  theme(panel.grid.minor = element_blank(),
        plot.title.position = "plot")

ggsave("Figures/Figure1B.png", plot = plot_min_index)


# Generate annual maps

library(haven)
library(spdep)
library(broom)
library(ggplot2)
library(plm)
library(spatstat.utils)
library(data.table)
library(patchwork)

shape<-readOGR("Input/gadm41_ECU_3.json")
shape<-shape[which(shape$NAME_1!="Galápagos"),]
b_shape<-fortify(shape)
temp_df <- data.frame(CC_3=shape@data$CC_3)
temp_df$id <- c(0:(length(unique(b_shape$id))-1))
temp_df$id<-as.character(temp_df$id)
b_shape<-left_join(b_shape, temp_df, by="id")
years <- sort(unique(annual_precipitation$year))

# Index_max maps
make_map_max <- function(yy){
  Data_sum <- filter(annual_precipitation, year == yy)
  mean_yy <- mean(Data_sum$index_max, na.rm = TRUE)
  
  gdat <- left_join(b_shape, Data_sum, by = "CC_3") |>
    mutate(index_max_plot = ifelse(is.na(index_max), mean_yy, index_max))
  
  ggplot() +
    geom_polygon(
      data = gdat,
      aes(x = long, y = lat, group = group, fill = index_max_plot),
      size = 0.05, color = NA
    ) +
    scale_fill_gradient2(
      low = "red", mid = "yellow", high = "blue",
      midpoint = 0, limits = c(min_index, max_index),
    ) +
    ggtitle(as.character(yy)) +
    theme_classic() +
    theme(
      axis.line = element_blank(),
      axis.text = element_blank(),
      axis.ticks = element_blank(),
      axis.title = element_blank(),
      plot.title = element_text(hjust = 0.5, size = 20)
    )
}

#Fix a common scale across all maps
min_index <- min(annual_precipitation$index_max, na.rm = TRUE)
max_index <- max(annual_precipitation$index_max, na.rm = TRUE)
maps_list_max <- lapply(years, make_map_max)
panel_max <- wrap_plots(maps_list_max, ncol = 6)
ggsave("Figures/Figure2A.png", panel_max, width = 30, height = 15)


# Index_min maps
make_map_min <- function(yy){
  Data_sum <- filter(annual_precipitation, year == yy)
  mean_yy <- mean(Data_sum$index_min, na.rm = TRUE)
  
  gdat <- left_join(b_shape, Data_sum, by = "CC_3") |>
    mutate(index = ifelse(is.na(index_min), mean_yy, index_min))
  
  ggplot() +
    geom_polygon(
      data = gdat,
      aes(x = long, y = lat, group = group, fill = index),
      size = 0.05, color = NA
    ) +
    scale_fill_gradient2(
      low = "red", mid = "yellow", high = "blue",
      midpoint = 0, limits = c(min_index, max_index),
    ) +
    ggtitle(as.character(yy)) +
    theme_classic() +
    theme(
      axis.line = element_blank(),
      axis.text = element_blank(),
      axis.ticks = element_blank(),
      axis.title = element_blank(),
      plot.title = element_text(hjust = 0.5, size = 20)
    )
}

#Fix a common scale across all maps
min_index <- min(annual_precipitation$index_min, na.rm = TRUE)
max_index <- max(annual_precipitation$index_min, na.rm = TRUE)
maps_list_min <- lapply(years, make_map_min)
panel_min <- wrap_plots(maps_list_min, ncol = 6)
ggsave("Figures/Figure2B.png", panel_min, width = 30, height = 15)

table(annual_precipitation$binary_excess_1, annual_precipitation$year)
table(annual_precipitation$binary_deficit_1, annual_precipitation$year)





